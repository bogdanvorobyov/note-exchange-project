function Error404() {
    return (
      <div>
        G
      </div>
    );
  }
  
  export default Error404;
  