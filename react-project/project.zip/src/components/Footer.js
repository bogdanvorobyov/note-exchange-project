function Footer() {
    return (
     <div className='footer'> 
       2020
     </div>
    );
  }
  
  export default Footer;
  